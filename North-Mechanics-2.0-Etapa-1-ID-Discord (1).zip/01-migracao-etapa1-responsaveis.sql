-- NORTH MECHANICS 2.0 - ETAPA 1 | STATUS + RESPONSAVEL + FILTROS
-- AMBIENTE DE HOMOLOGACAO PRIMEIRO. NAO execute direto no banco de producao.
-- Requer a estrutura 1.0: public.inscricoes, public.team_members.
-- A migracao e aditiva e nao apaga inscricoes nem contas existentes.
BEGIN;

DO $preflight$
BEGIN
  IF to_regclass('public.inscricoes') IS NULL OR to_regclass('public.team_members') IS NULL THEN
    RAISE EXCEPTION 'Estrutura 1.0 nao encontrada: inscricoes/team_members. Confira o projeto escolhido.';
  END IF;
END;
$preflight$;

ALTER TABLE public.inscricoes
  ADD COLUMN IF NOT EXISTS status_candidato text NOT NULL DEFAULT 'pendente',
  ADD COLUMN IF NOT EXISTS status_atualizado_em timestamptz,
  ADD COLUMN IF NOT EXISTS status_atualizado_por uuid,
  ADD COLUMN IF NOT EXISTS responsavel_id uuid,
  ADD COLUMN IF NOT EXISTS assumida_em timestamptz;

DO $constraints$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public.inscricoes'::regclass AND conname = 'north_status_candidato_valido') THEN
    ALTER TABLE public.inscricoes ADD CONSTRAINT north_status_candidato_valido
      CHECK (status_candidato IN ('pendente', 'em_analise', 'entrevista', 'aprovado', 'reprovado'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public.inscricoes'::regclass AND conname = 'north_inscricoes_responsavel_fkey') THEN
    ALTER TABLE public.inscricoes ADD CONSTRAINT north_inscricoes_responsavel_fkey
      FOREIGN KEY (responsavel_id) REFERENCES public.team_members(user_id) ON DELETE SET NULL;
  END IF;
END;
$constraints$;

CREATE INDEX IF NOT EXISTS north_inscricoes_status_idx ON public.inscricoes(status_candidato);
CREATE INDEX IF NOT EXISTS north_inscricoes_responsavel_idx ON public.inscricoes(responsavel_id);

-- Registro interno de atribuicoes/alteracoes, sem copiar as respostas dos candidatos.
CREATE TABLE IF NOT EXISTS public.north_inscricao_eventos (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  inscricao_id bigint REFERENCES public.inscricoes(id) ON DELETE SET NULL,
  autor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  acao text NOT NULL CHECK (acao IN ('assumir', 'liberar', 'transferir', 'status')),
  status_anterior text,
  status_novo text,
  responsavel_anterior uuid,
  responsavel_novo uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS north_eventos_inscricao_idx ON public.north_inscricao_eventos(inscricao_id,created_at DESC);
ALTER TABLE public.north_inscricao_eventos ENABLE ROW LEVEL SECURITY;

-- Historico: apenas ADM ativo pode consultar (interface completa vem em etapa posterior).
DROP POLICY IF EXISTS "North ADM consulta historico de inscricoes" ON public.north_inscricao_eventos;
CREATE POLICY "North ADM consulta historico de inscricoes"
  ON public.north_inscricao_eventos FOR SELECT TO authenticated
  USING ((SELECT private.is_admin()));
REVOKE ALL ON public.north_inscricao_eventos FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.north_inscricao_eventos TO authenticated;

-- Contato de usuarios ativos: necessario para exibir os nomes e permitir transferencias.
-- Somente ADMs/Recrutadores ativos podem usar a RPC. Nunca expor e-mails aqui.
CREATE OR REPLACE FUNCTION public.north_active_recruiters()
RETURNS TABLE(user_id uuid, nome text, cargo text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = ''
AS $active$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.team_members m
    WHERE m.user_id = (SELECT auth.uid()) AND m.status = 'ativo'
      AND m.cargo IN ('adm','recrutador')
  ) THEN
    RAISE EXCEPTION 'Acesso restrito a membros ativos';
  END IF;
  RETURN QUERY SELECT m.user_id, m.nome, m.cargo FROM public.team_members m
    WHERE m.status = 'ativo' AND m.cargo IN ('adm','recrutador')
    ORDER BY m.nome;
END;
$active$;

-- Assumir e mudar pendente -> em_analise, na MESMA transacao.
-- FOR UPDATE faz duas tentativas simultaneas concorrerem pela mesma linha.
CREATE OR REPLACE FUNCTION public.north_take_candidate(p_inscricao_id bigint)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $take$
DECLARE
  v_actor uuid := auth.uid();
  v_old_status text;
  v_owner uuid;
  v_new_status text;
BEGIN
  IF v_actor IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.team_members m
    WHERE m.user_id = v_actor AND m.status='ativo' AND m.cargo IN ('adm','recrutador')
  ) THEN
    RAISE EXCEPTION 'Somente ADM ou Recrutador ativo pode assumir';
  END IF;

  SELECT i.status_candidato, i.responsavel_id INTO v_old_status,v_owner
  FROM public.inscricoes i WHERE i.id=p_inscricao_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Inscricao nao encontrada'; END IF;
  IF v_owner IS NOT NULL THEN RAISE EXCEPTION 'Esta inscricao ja tem responsavel'; END IF;
  IF v_old_status IN ('aprovado','reprovado') THEN
    RAISE EXCEPTION 'Nao e possivel assumir inscricao encerrada';
  END IF;

  v_new_status := CASE WHEN v_old_status='pendente' THEN 'em_analise' ELSE v_old_status END;
  UPDATE public.inscricoes
  SET responsavel_id=v_actor, assumida_em=now(), status_candidato=v_new_status,
      status_atualizado_em=CASE WHEN v_old_status<>v_new_status THEN now() ELSE status_atualizado_em END,
      status_atualizado_por=CASE WHEN v_old_status<>v_new_status THEN v_actor ELSE status_atualizado_por END
  WHERE id=p_inscricao_id;
  INSERT INTO public.north_inscricao_eventos
    (inscricao_id,autor_id,acao,status_anterior,status_novo,responsavel_anterior,responsavel_novo)
  VALUES (p_inscricao_id,v_actor,'assumir',v_old_status,v_new_status,NULL,v_actor);
END;
$take$;

-- Liberar: o responsavel atual ou ADM. Em analise volta a pendente;
-- Entrevista e etapas finais preservam o status ao liberar.
CREATE OR REPLACE FUNCTION public.north_release_candidate(p_inscricao_id bigint)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $release$
DECLARE
  v_actor uuid := auth.uid();
  v_role text;
  v_old_status text;
  v_owner uuid;
  v_new_status text;
BEGIN
  SELECT m.cargo INTO v_role FROM public.team_members m
    WHERE m.user_id=v_actor AND m.status='ativo' AND m.cargo IN ('adm','recrutador');
  IF v_role IS NULL THEN RAISE EXCEPTION 'Acesso negado'; END IF;
  SELECT i.status_candidato,i.responsavel_id INTO v_old_status,v_owner
    FROM public.inscricoes i WHERE i.id=p_inscricao_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Inscricao nao encontrada'; END IF;
  IF v_owner IS NULL THEN RAISE EXCEPTION 'Inscricao nao possui responsavel'; END IF;
  IF v_owner IS DISTINCT FROM v_actor AND v_role <> 'adm' THEN
    RAISE EXCEPTION 'Somente o responsavel ou ADM pode liberar a inscricao';
  END IF;

  v_new_status := CASE WHEN v_old_status='em_analise' THEN 'pendente' ELSE v_old_status END;
  UPDATE public.inscricoes
  SET responsavel_id=NULL, assumida_em=NULL, status_candidato=v_new_status,
      status_atualizado_em=CASE WHEN v_old_status<>v_new_status THEN now() ELSE status_atualizado_em END,
      status_atualizado_por=CASE WHEN v_old_status<>v_new_status THEN v_actor ELSE status_atualizado_por END
  WHERE id=p_inscricao_id;
  INSERT INTO public.north_inscricao_eventos
    (inscricao_id,autor_id,acao,status_anterior,status_novo,responsavel_anterior,responsavel_novo)
  VALUES(p_inscricao_id,v_actor,'liberar',v_old_status,v_new_status,v_owner,NULL);
END;
$release$;

-- Transferir: somente ADM ativo escolhe outro membro ativo.
CREATE OR REPLACE FUNCTION public.north_transfer_candidate(p_inscricao_id bigint, p_novo_responsavel uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $transfer$
DECLARE
  v_actor uuid := auth.uid();
  v_old_status text;
  v_owner uuid;
  v_new_status text;
BEGIN
  IF v_actor IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.team_members m WHERE m.user_id=v_actor AND m.status='ativo' AND m.cargo='adm'
  ) THEN RAISE EXCEPTION 'Somente ADM ativo pode transferir'; END IF;
  IF p_novo_responsavel IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.team_members m WHERE m.user_id=p_novo_responsavel
      AND m.status='ativo' AND m.cargo IN ('adm','recrutador')
  ) THEN RAISE EXCEPTION 'Escolha um responsavel ativo'; END IF;

  SELECT i.status_candidato,i.responsavel_id INTO v_old_status,v_owner
    FROM public.inscricoes i WHERE i.id=p_inscricao_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Inscricao nao encontrada'; END IF;
  IF v_owner IS NOT DISTINCT FROM p_novo_responsavel THEN
    RAISE EXCEPTION 'O membro ja e responsavel';
  END IF;
  IF v_old_status IN ('aprovado','reprovado') THEN
    RAISE EXCEPTION 'Nao e possivel transferir inscricao encerrada';
  END IF;

  v_new_status:=CASE WHEN v_old_status='pendente' THEN 'em_analise' ELSE v_old_status END;
  UPDATE public.inscricoes SET
    responsavel_id=p_novo_responsavel,assumida_em=now(),status_candidato=v_new_status,
    status_atualizado_em=CASE WHEN v_old_status<>v_new_status THEN now() ELSE status_atualizado_em END,
    status_atualizado_por=CASE WHEN v_old_status<>v_new_status THEN v_actor ELSE status_atualizado_por END
  WHERE id=p_inscricao_id;
  INSERT INTO public.north_inscricao_eventos
    (inscricao_id,autor_id,acao,status_anterior,status_novo,responsavel_anterior,responsavel_novo)
  VALUES (p_inscricao_id,v_actor,'transferir',v_old_status,v_new_status,v_owner,p_novo_responsavel);
END;
$transfer$;

-- Alteracao manual de status: ADM ou proprietario ativo da inscricao.
-- Recrutador nao pode alterar status de inscricao de outra pessoa.
CREATE OR REPLACE FUNCTION public.north_set_candidate_status(p_inscricao_id bigint,p_status text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = ''
AS $status$
DECLARE
  v_actor uuid := auth.uid();
  v_role text;
  v_old_status text;
  v_owner uuid;
BEGIN
  SELECT m.cargo INTO v_role FROM public.team_members m
    WHERE m.user_id=v_actor AND m.status='ativo' AND m.cargo IN ('adm','recrutador');
  IF v_role IS NULL THEN RAISE EXCEPTION 'ADM ou Recrutador ativo necessario'; END IF;
  IF p_status IS NULL OR p_status NOT IN ('pendente','em_analise','entrevista','aprovado','reprovado') THEN
    RAISE EXCEPTION 'Status invalido';
  END IF;
  SELECT i.status_candidato,i.responsavel_id INTO v_old_status,v_owner
    FROM public.inscricoes i WHERE i.id=p_inscricao_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Inscricao nao encontrada'; END IF;
  IF v_role='recrutador' AND v_owner IS DISTINCT FROM v_actor THEN
    RAISE EXCEPTION 'Assuma a inscricao para alterar o status';
  END IF;
  IF p_status='pendente' AND v_owner IS NOT NULL THEN
    RAISE EXCEPTION 'Libere a inscricao para retornar ao status Pendente';
  END IF;
  IF v_old_status=p_status THEN RETURN; END IF;

  UPDATE public.inscricoes SET status_candidato=p_status,status_atualizado_em=now(),status_atualizado_por=v_actor
  WHERE id=p_inscricao_id;
  INSERT INTO public.north_inscricao_eventos
    (inscricao_id,autor_id,acao,status_anterior,status_novo,responsavel_anterior,responsavel_novo)
  VALUES(p_inscricao_id,v_actor,'status',v_old_status,p_status,v_owner,v_owner);
END;
$status$;

-- Nenhum navegador recebe permissão UPDATE direta.
REVOKE UPDATE ON public.inscricoes FROM PUBLIC, anon, authenticated;

REVOKE ALL ON FUNCTION public.north_active_recruiters() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.north_take_candidate(bigint) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.north_release_candidate(bigint) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.north_transfer_candidate(bigint,uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.north_set_candidate_status(bigint,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.north_active_recruiters() TO authenticated;
GRANT EXECUTE ON FUNCTION public.north_take_candidate(bigint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.north_release_candidate(bigint) TO authenticated;
GRANT EXECUTE ON FUNCTION public.north_transfer_candidate(bigint,uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.north_set_candidate_status(bigint,text) TO authenticated;

COMMIT;

-- Confere dados e quantos registros continuam na tabela (nao mostra respostas).
SELECT status_candidato, COUNT(*) AS quantidade
FROM public.inscricoes GROUP BY status_candidato ORDER BY status_candidato;
